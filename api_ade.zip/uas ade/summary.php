<?php
include 'koneksi.php';

$user_id = $_GET['user_id'] ?? '';

if (!$user_id) {
    echo json_encode(['success' => false, 'pesan' => 'user_id tidak dikirim']);
    exit;
}

$query = $conn->query("SELECT 
    SUM(CASE WHEN jenis = 'pemasukan' THEN jumlah ELSE 0 END) AS total_pemasukan,
    SUM(CASE WHEN jenis = 'pengeluaran' THEN jumlah ELSE 0 END) AS total_pengeluaran
    FROM transactions WHERE user_id = '$user_id'");

$result = $query->fetch_assoc();

echo json_encode([
    'success' => true,
    'data' => $result
]);
?>
