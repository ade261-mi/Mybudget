<?php
include 'koneksi.php';

// Ambil data dari POST (x-www-form-urlencoded)
$id_transaksi = $_POST['id_transaksi'] ?? null;

if (!$id_transaksi) {
    echo json_encode([
        "success" => false,
        "pesan" => "ID transaksi tidak dikirim"
    ]);
    exit;
}

// Jalankan query delete
$query = $conn->query("DELETE FROM transactions WHERE id_transaksi = '$id_transaksi'");

if ($query) {
    echo json_encode([
        "success" => true,
        "pesan" => "Transaksi berhasil dihapus"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "pesan" => "Gagal menghapus transaksi"
    ]);
}
?>
