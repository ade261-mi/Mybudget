<?php
include 'koneksi.php';

// Ambil data dari form (x-www-form-urlencoded)
$id_transaksi = $_POST['id_transaksi'] ?? null;
$jenis        = $_POST['jenis'] ?? null;
$jumlah       = $_POST['jumlah'] ?? null;
$kategori     = $_POST['kategori'] ?? null;
$catatan      = $_POST['catatan'] ?? null;

// Validasi
if (!$id_transaksi || !$jenis || !$jumlah || !$kategori) {
    echo json_encode(["success" => false, "pesan" => "Data tidak lengkap."]);
    exit;
}

// Update query
$query = $conn->query("UPDATE transactions SET
  jenis = '$jenis',
  jumlah = '$jumlah',
  kategori = '$kategori',
  catatan = '$catatan'
WHERE id_transaksi = '$id_transaksi'");

if ($query) {
    echo json_encode(["success" => true, "pesan" => "Transaksi berhasil diperbarui"]);
} else {
    echo json_encode(["success" => false, "pesan" => "Gagal memperbarui transaksi"]);
}
?>
