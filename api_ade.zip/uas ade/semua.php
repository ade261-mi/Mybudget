<?php
include 'koneksi.php';

// Cek apakah parameter user_id tersedia di POST
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    $query = $conn->query("SELECT * FROM transactions WHERE user_id = '$user_id'");
    $data = [];

    while ($row = $query->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode([
        "success" => true,
        "data" => $data
    ]);

} else {
    echo json_encode([
        "success" => false,
        "pesan" => "Parameter 'user_id' tidak ditemukan"
    ]);
}
?>
