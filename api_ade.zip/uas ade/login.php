<?php
include 'koneksi.php'; // Menghubungkan ke database

// Ambil data dari POST (x-www-form-urlencoded)
$email    = $_POST['email'] ?? null;
$password = $_POST['password'] ?? null;

if (!$email || !$password) {
    echo json_encode([
        "success" => false,
        "pesan"   => "Email dan password wajib diisi"
    ]);
    exit;
}

// Lindungi dari SQL injection
$email    = $conn->real_escape_string($email);
$password = $conn->real_escape_string($password);

// Cari user berdasarkan email dan password
$query = $conn->query("SELECT * FROM users WHERE email='$email' AND password='$password'");

if ($query->num_rows > 0) {
    $user = $query->fetch_assoc();
    echo json_encode([
        "success" => true,
        "pesan"   => "Login berhasil",
        "user"    => $user
    ]);
} else {
    echo json_encode([
        "success" => false,
        "pesan"   => "Email atau password salah"
    ]);
}
?>
