<?php
include 'koneksi.php';

// Ambil parameter 'jenis' dari x-www-form-urlencoded (POST)
$jenis = $_POST['jenis'] ?? null;

if (!$jenis) {
    echo json_encode([
        "success" => false,
        "pesan" => "Parameter 'jenis' tidak ditemukan"
    ]);
    exit;
}

// Ambil data kategori sesuai jenis
$query = $conn->query("SELECT * FROM kategori WHERE jenis = '$jenis'");
$data = [];

while ($row = $query->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode([
    "success" => true,
    "data" => $data
]);
?>
