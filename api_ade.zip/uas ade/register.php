<?php
include 'koneksi.php';

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (!$name || !$email || !$password) {
    echo json_encode(["success" => false, "pesan" => "Data tidak lengkap"]);
    exit;
}

$query = $conn->query("INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')");

if ($query) {
    echo json_encode(["success" => true, "pesan" => "Registrasi berhasil"]);
} else {
    echo json_encode(["success" => false, "pesan" => "Gagal registrasi"]);
}
?>
