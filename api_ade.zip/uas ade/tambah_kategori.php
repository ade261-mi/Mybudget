<?php
include 'koneksi.php';

$user_id = $_GET['user_id'];

$pemasukan = 0;
$pengeluaran = 0;

$sql1 = $conn->query("SELECT SUM(jumlah) as total FROM transactions WHERE user_id='$user_id' AND jenis='pemasukan'");
$row1 = $sql1->fetch_assoc();
$pemasukan = $row1['total'] ?? 0;

$sql2 = $conn->query("SELECT SUM(jumlah) as total FROM transactions WHERE user_id='$user_id' AND jenis='pengeluaran'");
$row2 = $sql2->fetch_assoc();
$pengeluaran = $row2['total'] ?? 0;

echo json_encode([
  'success' => true,
  'pemasukan' => $pemasukan,
  'pengeluaran' => $pengeluaran
]);
?>
