// Import package yang dibutuhkan
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

// Import halaman lain
import 'beranda_screen.dart';
import 'register_screen.dart';
import 'config.dart';

// Widget stateful untuk halaman login
class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // Controller untuk mengambil input email dan password
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  // Status loading saat login berlangsung
  bool loading = false;

  // Fungsi untuk menampilkan pesan dalam bentuk dialog
  void showMessage(String pesan) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Peringatan"),
        content: Text(pesan),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }

  // Fungsi untuk menangani proses login
  Future<void> login() async {
    final email = emailController.text.trim();
    final password = passwordController.text;

    // Validasi input kosong
    if (email.isEmpty || password.isEmpty) {
      showMessage("Email dan password harus diisi");
      return;
    }

    // Validasi format email
    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email)) {
      showMessage("Format email tidak valid");
      return;
    }

    // Set status loading saat login dimulai
    setState(() => loading = true);

    try {
      // Kirim request POST ke endpoint login
      final response = await http.post(
        Uri.parse('$baseUrl/login.php'),
        body: {'email': email, 'password': password},
      );

      // Decode hasil response dari JSON
      final data = json.decode(response.body);

      // Jika login berhasil, simpan data pengguna di SharedPreferences
      if (data['success']) {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString('user_id', data['user']['id']);
        prefs.setString('name', data['user']['name']);
        prefs.setString('email', data['user']['email']);

        // Arahkan ke halaman beranda setelah login
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => BerandaScreen()),
        );
      } else {
        // Jika gagal, tampilkan pesan dari server
        showMessage(data['pesan'] ?? 'Login gagal');
      }
    } catch (e) {
      // Tangani error koneksi atau server
      showMessage('Terjadi kesalahan: $e');
    } finally {
      // Selesai loading
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFE1F5FE), // Warna latar belakang biru pastel
      appBar: AppBar(
        backgroundColor: Color(0xFFB3E5FC),
        title: Text("Login", style: TextStyle(color: Colors.black)),
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Judul selamat datang
              Text(
                "Selamat Datang!",
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),

              // Input field email
              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: "Email",
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              SizedBox(height: 16),

              // Input field password
              TextField(
                controller: passwordController,
                decoration: InputDecoration(
                  labelText: "Password",
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  prefixIcon: Icon(Icons.lock),
                ),
                obscureText: true,
              ),
              SizedBox(height: 24),

              // Tombol login atau loading indicator
              loading
                  ? Center(child: CircularProgressIndicator())
                  : ElevatedButton(
                onPressed: login,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding: EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text("Masuk", style: TextStyle(fontSize: 16)),
              ),
              SizedBox(height: 12),

              // Tombol untuk pindah ke halaman register
              TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => RegisterScreen()));
                },
                child: Text(
                  "Belum punya akun? Daftar di sini",
                  style: TextStyle(color: Colors.black54),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
