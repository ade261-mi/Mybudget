// Import package HTTP untuk melakukan request ke server
import 'package:http/http.dart' as http;

// Import library untuk mengubah data JSON
import 'dart:convert';

// Import konfigurasi baseUrl dari file config.dart
import 'config.dart';

// Fungsi async untuk mengambil daftar kategori berdasarkan jenis ('pemasukan' atau 'pengeluaran')
Future<List<String>> fetchKategori(String jenis) async {
  // Kirim request POST ke API kategori.php dengan parameter jenis
  final res = await http.post(
    Uri.parse('$baseUrl/kategori.php'),
    body: {'jenis': jenis},
  );

  // Ubah response JSON menjadi bentuk data Dart
  final data = json.decode(res.body);

  // Jika request gagal atau data tidak ditemukan, kembalikan list kosong
  if (data['success'] == false) return [];

  // Jika sukses, ambil semua nama_kategori dari data dan ubah ke list string
  return List<String>.from(data['data'].map((k) => k['nama_kategori']));
}
