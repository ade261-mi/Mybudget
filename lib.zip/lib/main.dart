// Import package yang dibutuhkan
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Import file layar login dan home
import 'login_screen.dart';
import 'home_screen.dart';

// Fungsi utama yang dijalankan pertama kali saat aplikasi dibuka
void main() {
  runApp(MyApp()); // Menjalankan aplikasi MyApp
}

// Widget stateless utama dari aplikasi
class MyApp extends StatelessWidget {
  // Fungsi untuk mengambil user_id dari SharedPreferences
  Future<String?> getUserId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_id'); // Mengembalikan user_id jika ada
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyBudget', // Judul aplikasi
      theme: ThemeData(primarySwatch: Colors.purple), // Tema warna ungu

      // Menentukan halaman pertama berdasarkan login atau tidak
      home: FutureBuilder<String?>(
        future: getUserId(), // Menjalankan fungsi getUserId()
        builder: (context, snapshot) {
          // Jika masih menunggu data user_id, tampilkan loading
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Scaffold(body: Center(child: CircularProgressIndicator()));
          } else {
            // Jika user_id tidak ditemukan, tampilkan LoginScreen
            // Jika user_id ditemukan, langsung ke HomeScreen
            return snapshot.data == null
                ? LoginScreen()
                : HomeScreen(userId: snapshot.data!);
          }
        },
      ),
    );
  }
}
