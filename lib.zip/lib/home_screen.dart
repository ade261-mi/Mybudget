// Import library Flutter dan SharedPreferences
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
// Import file screen yang dibutuhkan
import 'beranda_screen.dart';
import 'tambah_transaksi_screen.dart';
import 'daftar_transaksi_screen.dart';
import 'tambah_kategori_screen.dart';
import 'tentang_screen.dart';
import 'login_screen.dart';
import 'profil_screen.dart';

// Deklarasi StatefulWidget untuk halaman Home
class HomeScreen extends StatefulWidget {
  final String userId; // Menerima user ID dari luar

  const HomeScreen({required this.userId, Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState(); // Membuat state
}

class _HomeScreenState extends State<HomeScreen> {
  String name = ''; // Menyimpan nama pengguna
  int _selectedIndex = 0; // Menyimpan indeks BottomNavigationBar yang aktif

  @override
  void initState() {
    super.initState();
    getName(); // Ambil nama saat halaman dimuat
  }

  // Fungsi untuk mengambil nama dari SharedPreferences
  Future<void> getName() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      name = prefs.getString('name') ?? ''; // Ambil nama atau kosong jika null
    });
  }

  // Fungsi logout, membersihkan data login dan kembali ke login screen
  void logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear(); // Hapus semua data
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => LoginScreen()), // Arahkan ke halaman login
    );
  }

  // Fungsi untuk mengatur navigasi saat menu bawah ditekan
  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index); // Update index

    switch (index) {
      case 0: // Beranda
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => BerandaScreen()),
        );
        break;
      case 1: // Daftar Transaksi
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => DaftarTransaksiScreen(userId: widget.userId)),
        );
        break;
      case 2: // Tambah Transaksi
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => TambahTransaksiScreen(userId: widget.userId)),
        );
        break;
      case 3: // Tambah Kategori
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => TambahKategoriScreen(userId: widget.userId, jenis: 'pemasukan')),
        );
        break;
      case 4: // Tentang Aplikasi
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => TentangScreen(userId: widget.userId)),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar di atas layar
      appBar: AppBar(
        title: Text('MyBudget - $name'), // Tampilkan nama user di judul
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: logout, // Aksi logout saat ditekan
          )
        ],
      ),

      // Isi halaman
      body: Center(
        child: Text(
          'Selamat datang, $name 👋', // Sambutan untuk user
          style: TextStyle(fontSize: 20),
        ),
      ),

      // Bottom navigation bar untuk navigasi antar halaman
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex, // Menu aktif saat ini
        onTap: _onItemTapped, // Aksi saat menu ditekan
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.purple, // Warna menu aktif
        unselectedItemColor: Colors.grey, // Warna menu tidak aktif
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: "Transaksi"),
          BottomNavigationBarItem(icon: Icon(Icons.add), label: "Tambah"),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: "Kategori"),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: "Tentang"),
        ],
      ),
    );
  }
}
