// Import library yang dibutuhkan
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config.dart';

// Membuat halaman registrasi sebagai StatelessWidget
class RegisterScreen extends StatelessWidget {
  // Controller untuk input nama, email, dan password
  final nameCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  // Fungsi untuk proses registrasi
  void register(BuildContext context) async {
    final name = nameCtrl.text.trim(); // Mengambil nama dan menghilangkan spasi di awal/akhir
    final email = emailCtrl.text.trim();
    final pass = passCtrl.text;

    // Validasi nama hanya boleh huruf
    if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(name)) {
      showMessage(context, 'Nama hanya boleh huruf');
      return;
    }

    // Validasi format email
    if (!email.contains('@') || !RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email)) {
      showMessage(context, 'Format email tidak valid');
      return;
    }

    // Validasi panjang password minimal 6 karakter
    if (pass.length < 6) {
      showMessage(context, 'Password minimal 6 karakter');
      return;
    }

    // Kirim data registrasi ke server menggunakan POST
    var res = await http.post(Uri.parse('$baseUrl/register.php'), body: {
      'name': name,
      'email': email,
      'password': pass,
    });

    // Decode response dari server
    var data = json.decode(res.body);

    // Jika berhasil, tampilkan pesan dan kembali ke halaman sebelumnya
    if (data['success']) {
      showMessage(context, 'Registrasi berhasil');
      Navigator.pop(context); // Kembali ke halaman login
    } else {
      // Jika gagal, tampilkan pesan dari server
      showMessage(context, data['pesan']);
    }
  }

  // Fungsi untuk menampilkan SnackBar berisi pesan
  void showMessage(BuildContext context, String pesan) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(pesan)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFE1F5FE), // Warna latar biru pastel
      appBar: AppBar(
        backgroundColor: Color(0xFFB3E5FC), // Warna AppBar biru muda
        title: Text('Daftar Akun', style: TextStyle(color: Colors.black)),
        iconTheme: IconThemeData(color: Colors.black), // Warna ikon kembali
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(24), // Padding isi body
        child: Column(
          children: [
            Icon(Icons.account_circle, size: 100, color: Colors.blueAccent), // Ikon avatar
            SizedBox(height: 20),
            // Input nama
            TextField(
              controller: nameCtrl,
              decoration: InputDecoration(
                labelText: 'Nama Lengkap',
                border: OutlineInputBorder(),
                fillColor: Colors.white,
                filled: true,
              ),
            ),
            SizedBox(height: 16),
            // Input email
            TextField(
              controller: emailCtrl,
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
                fillColor: Colors.white,
                filled: true,
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 16),
            // Input password
            TextField(
              controller: passCtrl,
              decoration: InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
                fillColor: Colors.white,
                filled: true,
              ),
              obscureText: true, // Menyembunyikan teks password
            ),
            SizedBox(height: 24),
            // Tombol daftar
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => register(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding: EdgeInsets.symmetric(vertical: 14),
                ),
                child: Text('Daftar', style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
