import 'dart:convert'; // Import library untuk mengolah data JSON
import 'package:flutter/material.dart'; // Import library Flutter untuk UI
import 'package:http/http.dart' as http; // Import library HTTP untuk koneksi API

// Import file lokal
import 'config.dart';
import 'profil_screen.dart';
import 'beranda_screen.dart';
import 'tambah_transaksi_screen.dart';
import 'tambah_kategori_screen.dart';
import 'tentang_screen.dart';

class DaftarTransaksiScreen extends StatefulWidget {
  final String userId; // Menyimpan ID user dari parameter
  DaftarTransaksiScreen({required this.userId}); // Konstruktor wajib isi userId

  @override
  _DaftarTransaksiScreenState createState() => _DaftarTransaksiScreenState(); // Buat state
}

class _DaftarTransaksiScreenState extends State<DaftarTransaksiScreen> {
  List<dynamic> transaksi = []; // List untuk menyimpan data transaksi
  int _selectedIndex = 1; // Index default di BottomNavigationBar (halaman transaksi)

  @override
  void initState() {
    super.initState();
    fetchTransaksi(); // Ambil data saat halaman dimuat pertama kali
  }

  // Fungsi untuk mengambil semua data transaksi dari API
  Future<void> fetchTransaksi() async {
    final response = await http.get(Uri.parse('$baseUrl/semua.php?user_id=${widget.userId}'));

    if (response.statusCode == 200) {
      final result = json.decode(response.body);
      if (result['success'] == true) {
        setState(() {
          transaksi = result['data']; // Simpan data ke dalam state
        });
      }
    }
  }

  // Fungsi untuk menghapus transaksi berdasarkan ID
  Future<void> hapusTransaksi(String id) async {
    final res = await http.post(
      Uri.parse('$baseUrl/hapus.php'),
      body: {'id_transaksi': id},
    );
    final data = json.decode(res.body);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['pesan'] ?? '')));
    if (data['success']) fetchTransaksi(); // Refresh setelah berhasil hapus
  }

  // Fungsi untuk mengubah data transaksi
  Future<void> ubahTransaksi(Map<String, dynamic> item) async {
    // Controller untuk isian form
    TextEditingController jumlahController = TextEditingController(text: item['jumlah']);
    TextEditingController kategoriController = TextEditingController(text: item['kategori']);
    TextEditingController catatanController = TextEditingController(text: item['catatan']);
    String jenis = item['jenis']; // Jenis default

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Ubah Transaksi'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              // Dropdown untuk memilih jenis transaksi
              DropdownButtonFormField<String>(
                value: jenis,
                decoration: InputDecoration(labelText: 'Jenis'),
                items: ['pemasukan', 'pengeluaran']
                    .map((e) => DropdownMenuItem(child: Text(e), value: e))
                    .toList(),
                onChanged: (val) {
                  if (val != null) jenis = val; // Update jenis
                },
              ),
              // Input jumlah
              TextField(
                controller: jumlahController,
                decoration: InputDecoration(labelText: 'Jumlah'),
                keyboardType: TextInputType.number,
              ),
              // Input kategori
              TextField(
                controller: kategoriController,
                decoration: InputDecoration(labelText: 'Kategori'),
              ),
              // Input catatan
              TextField(
                controller: catatanController,
                decoration: InputDecoration(labelText: 'Catatan'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context), // Tutup dialog
            child: Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              // Kirim data ke API ubah
              final res = await http.post(
                Uri.parse('$baseUrl/ubah.php'),
                body: {
                  'id_transaksi': item['id_transaksi'],
                  'jenis': jenis,
                  'jumlah': jumlahController.text,
                  'kategori': kategoriController.text,
                  'catatan': catatanController.text,
                },
              );
              final result = json.decode(res.body);
              Navigator.pop(context); // Tutup dialog
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result['pesan'])));
              if (result['success']) fetchTransaksi(); // Refresh data
            },
            child: Text('Simpan'),
          ),
        ],
      ),
    );
  }

  // Navigasi saat menu bawah diklik
  void _onItemTapped(int index) {
    if (index == _selectedIndex) return; // Jangan lakukan apa-apa jika klik menu yang sama
    setState(() => _selectedIndex = index);

    // Navigasi ke halaman lain
    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => BerandaScreen()));
        break;
      case 1:
        break;
      case 2:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => TambahKategoriScreen(userId: widget.userId, jenis: 'pemasukan')),
        );
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => TentangScreen(userId: widget.userId)),
        );
        break;
      case 4:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => ProfilScreen(userId: widget.userId)),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF1F8FF), // Warna latar belakang
      appBar: AppBar(
        backgroundColor: Color(0xFFB3E5FC), // Warna AppBar
        foregroundColor: Colors.black,
        title: Text("Daftar Transaksi"), // Judul
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              // Buka halaman tambah transaksi
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => TambahTransaksiScreen(userId: widget.userId)),
              ).then((_) => fetchTransaksi()); // Refresh data setelah kembali
            },
          )
        ],
      ),
      body: transaksi.isEmpty
          ? Center(child: Text("Belum ada transaksi")) // Tampilkan jika kosong
          : RefreshIndicator(
        onRefresh: fetchTransaksi,
        child: ListView.builder(
          itemCount: transaksi.length,
          itemBuilder: (context, index) {
            final item = transaksi[index];
            return Card(
              margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: ListTile(
                title: Text(
                  "${item['jenis'].toUpperCase()} - Rp ${item['jumlah']}",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text("${item['kategori']} | ${item['catatan']}"),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit, color: Colors.blue),
                      onPressed: () => ubahTransaksi(item),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => hapusTransaksi(item['id_transaksi']),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      // Bottom navigation bar untuk navigasi antar halaman
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color(0xFFE1F5FE),
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: "Transaksi"),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: "Kategori"),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: "Tentang"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }
}
