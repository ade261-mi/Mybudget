// Import library yang dibutuhkan
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config.dart'; // File konfigurasi baseUrl
import 'beranda_screen.dart';
import 'daftar_transaksi_screen.dart';
import 'tambah_kategori_screen.dart';
import 'tentang_screen.dart';
import 'profil_screen.dart';

// Halaman Tambah Transaksi
class TambahTransaksiScreen extends StatefulWidget {
  final String userId; // ID pengguna
  TambahTransaksiScreen({required this.userId});

  @override
  _TambahTransaksiScreenState createState() => _TambahTransaksiScreenState();
}

class _TambahTransaksiScreenState extends State<TambahTransaksiScreen> {
  String jenis = 'pemasukan'; // Default jenis transaksi
  String? kategoriDipilih; // Kategori yang dipilih user
  List<String> kategoriList = []; // List kategori yang ditampilkan di dropdown
  int _selectedIndex = 2; // Index untuk BottomNavigationBar

  TextEditingController jumlahCtrl = TextEditingController(); // Controller input jumlah
  TextEditingController catatanCtrl = TextEditingController(); // Controller input catatan

  @override
  void initState() {
    super.initState();
    loadKategori(); // Panggil saat halaman dibuka
  }

  // Fungsi untuk memuat kategori berdasarkan jenis
  Future<void> loadKategori() async {
    try {
      final res = await http.post(Uri.parse('$baseUrl/kategori.php'), body: {
        'action': 'get',
        'jenis': jenis,
      });

      final data = json.decode(res.body);
      if (data['success']) {
        setState(() {
          kategoriList = List<String>.from(data['data'].map((k) => k['nama_kategori']));
          kategoriDipilih = null; // Reset pilihan kategori saat jenis berubah
        });
      }
    } catch (e) {
      showAlert("Gagal memuat kategori: $e");
    }
  }

  // Fungsi untuk menampilkan pesan alert dialog
  void showAlert(String pesan) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Color(0xFFE1F5FE),
        title: Text("Informasi", style: TextStyle(color: Colors.black)),
        content: Text(pesan, style: TextStyle(color: Colors.black87)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: Colors.blue)),
          ),
        ],
      ),
    );
  }

  // Fungsi untuk menyimpan data transaksi ke server
  void simpanTransaksi() async {
    final jumlah = jumlahCtrl.text.trim();
    final catatan = catatanCtrl.text.trim();

    // Validasi input
    if (jumlah.isEmpty || kategoriDipilih == null) {
      showAlert("Jumlah dan kategori harus diisi");
      return;
    }

    final res = await http.post(
      Uri.parse('$baseUrl/tambah.php'),
      body: {
        'user_id': widget.userId,
        'jenis': jenis,
        'jumlah': jumlah,
        'kategori': kategoriDipilih!,
        'catatan': catatan,
      },
    );

    final data = json.decode(res.body);
    showAlert(data['pesan'] ?? 'Gagal simpan');

    if (data['success']) {
      // Tutup halaman setelah 1 detik jika berhasil
      Future.delayed(Duration(seconds: 1), () => Navigator.pop(context));
    }
  }

  // Fungsi navigasi BottomNavigationBar
  void _onItemTapped(int index) {
    if (index == _selectedIndex) return;
    setState(() => _selectedIndex = index);

    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => BerandaScreen()));
        break;
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(
            builder: (_) => DaftarTransaksiScreen(userId: widget.userId)));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(
            builder: (_) => TambahKategoriScreen(userId: widget.userId, jenis: jenis)));
        break;
      case 4:
        Navigator.pushReplacement(context, MaterialPageRoute(
            builder: (_) => TentangScreen(userId: widget.userId)));
        break;
      case 5:
        Navigator.pushReplacement(context, MaterialPageRoute(
            builder: (_) => ProfilScreen(userId: widget.userId)));
        break;
    }
  }

  // Tampilan utama halaman
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFE1F5FE), // Warna latar belakang
      appBar: AppBar(
        title: Text('Tambah Transaksi', style: TextStyle(color: Colors.black)),
        backgroundColor: Color(0xFFB3E5FC),
        iconTheme: IconThemeData(color: Colors.black),
        elevation: 1,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Dropdown jenis transaksi
              DropdownButtonFormField<String>(
                value: jenis,
                decoration: InputDecoration(
                  labelText: 'Jenis',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
                items: ['pemasukan', 'pengeluaran']
                    .map((j) => DropdownMenuItem(value: j, child: Text(j)))
                    .toList(),
                onChanged: (val) {
                  if (val != null) {
                    setState(() => jenis = val); // Update jenis
                    loadKategori(); // Reload kategori berdasarkan jenis baru
                  }
                },
              ),
              SizedBox(height: 12),
              // Dropdown kategori berdasarkan jenis
              DropdownButtonFormField<String>(
                value: kategoriDipilih,
                decoration: InputDecoration(
                  labelText: 'Kategori',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
                items: kategoriList
                    .map((k) => DropdownMenuItem(value: k, child: Text(k)))
                    .toList(),
                onChanged: (val) => setState(() => kategoriDipilih = val),
              ),
              SizedBox(height: 12),
              // Input jumlah
              TextField(
                controller: jumlahCtrl,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Jumlah',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
              SizedBox(height: 12),
              // Input catatan
              TextField(
                controller: catatanCtrl,
                decoration: InputDecoration(
                  labelText: 'Catatan',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
              SizedBox(height: 20),
              // Tombol simpan transaksi
              ElevatedButton.icon(
                onPressed: simpanTransaksi,
                icon: Icon(Icons.save),
                label: Text("Simpan"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  minimumSize: Size(double.infinity, 48),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ],
          ),
        ),
      ),
      // BottomNavigationBar
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: "Transaksi"),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: "Kategori"),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: "Tentang"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }
}
