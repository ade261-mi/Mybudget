// Import pustaka yang dibutuhkan
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'beranda_screen.dart';
import 'daftar_transaksi_screen.dart';
import 'tambah_kategori_screen.dart';
import 'profil_screen.dart';

// Halaman Tentang Aplikasi
class TentangScreen extends StatefulWidget {
  final String userId; // Diperlukan untuk navigasi ke halaman lain
  TentangScreen({required this.userId});

  @override
  _TentangScreenState createState() => _TentangScreenState();
}

class _TentangScreenState extends State<TentangScreen> {
  int _selectedIndex = 3; // Untuk BottomNavigationBar
  final PageController _pageController = PageController(); // Mengontrol carousel
  int _currentPage = 0; // Menyimpan halaman carousel aktif
  Timer? _carouselTimer; // Timer untuk auto-scroll

  // Daftar gambar carousel
  final List<Widget> _carouselItems = [
    ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.asset('assets/1.png', fit: BoxFit.cover), // Gambar lokal
    ),
    ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.network(
        'https://www.mybudget.com.au/wp-content/uploads/mb_calculators_post.jpg',
        fit: BoxFit.cover, // Gambar dari internet
      ),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _startAutoScroll(); // Mulai auto-scroll carousel saat init
  }

  // Fungsi auto-scroll carousel tiap 3 detik
  void _startAutoScroll() {
    _carouselTimer = Timer.periodic(Duration(seconds: 3), (timer) {
      if (_currentPage < _carouselItems.length - 1) {
        _currentPage++;
      } else {
        _currentPage = 0;
      }
      if (_pageController.hasClients) {
        _pageController.animateToPage(
          _currentPage,
          duration: Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _carouselTimer?.cancel(); // Hentikan timer saat keluar halaman
    _pageController.dispose(); // Dispose controller
    super.dispose();
  }

  // Navigasi berdasarkan item BottomNavigationBar
  void _onItemTapped(int index) {
    if (index == _selectedIndex) return;
    switch (index) {
      case 0:
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => BerandaScreen()));
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => DaftarTransaksiScreen(userId: widget.userId)),
        );
        break;
      case 2:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (_) => TambahKategoriScreen(userId: widget.userId, jenis: 'pemasukan')),
        );
        break;
      case 4:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => ProfilScreen(userId: widget.userId)),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final pastelBlue = Color(0xFFB3E5FC);       // Biru pastel untuk elemen pasif
    final pastelBlueDark = Color(0xFF0288D1);   // Biru lebih gelap untuk elemen aktif

    return Scaffold(
      appBar: AppBar(
        title: Text('Tentang Aplikasi'),
        backgroundColor: pastelBlueDark,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Carousel Gambar
            SizedBox(
              height: 200,
              child: PageView(
                controller: _pageController,
                children: _carouselItems,
                onPageChanged: (index) {
                  setState(() {
                    _currentPage = index;
                  });
                },
              ),
            ),
            SizedBox(height: 10),
            Center(
              child: SmoothPageIndicator(
                controller: _pageController,
                count: _carouselItems.length,
                effect: WormEffect(
                  dotHeight: 10,
                  dotWidth: 10,
                  activeDotColor: pastelBlueDark,
                  dotColor: pastelBlue,
                ),
              ),
            ),
            SizedBox(height: 30),

            // Judul Aplikasi
            Text(
              'MyBudget',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: pastelBlueDark,
              ),
            ),
            SizedBox(height: 10),

            // Deskripsi aplikasi
            Text(
              'Aplikasi MyBudget adalah aplikasi pencatat keuangan yang membantu kamu '
                  'mengatur pemasukan dan pengeluaran sehari-hari. Dengan diagram pie dan fitur transaksi '
                  'serta kategori, aplikasi ini mempermudah pemantauan keuangan pribadi secara cepat dan efisien.',
              style: TextStyle(fontSize: 16),
            ),

            SizedBox(height: 30),
            Text('Versi Aplikasi: 1.0.0', style: TextStyle(fontSize: 14)),
            Text('Dibuat oleh: Tim MyBudget', style: TextStyle(fontSize: 14)),
          ],
        ),
      ),

      // BottomNavigationBar untuk navigasi antar halaman utama
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: pastelBlueDark,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: "Transaksi"),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: "Kategori"),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: "Tentang"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }
}
