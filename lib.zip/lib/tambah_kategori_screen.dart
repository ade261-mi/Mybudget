// Import library yang dibutuhkan
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'config.dart'; // Konfigurasi baseUrl
import 'beranda_screen.dart';
import 'daftar_transaksi_screen.dart';
import 'tentang_screen.dart';
import 'profil_screen.dart';

// Widget Stateful untuk menambahkan kategori
class TambahKategoriScreen extends StatefulWidget {
  final String userId; // ID pengguna dari SharedPreferences
  final String jenis;  // Jenis kategori (pemasukan/pengeluaran)

  TambahKategoriScreen({required this.userId, required this.jenis});

  @override
  State<TambahKategoriScreen> createState() => _TambahKategoriScreenState();
}

class _TambahKategoriScreenState extends State<TambahKategoriScreen> {
  final TextEditingController namaKategoriCtrl = TextEditingController(); // Controller untuk nama kategori
  late String jenis; // State jenis kategori
  bool loading = false; // Untuk menampilkan loading saat simpan
  int _selectedIndex = 2; // Index untuk BottomNavigationBar

  @override
  void initState() {
    super.initState();
    jenis = widget.jenis; // Inisialisasi jenis dari parameter
  }

  // Fungsi untuk menyimpan kategori ke server
  Future<void> simpanKategori() async {
    String nama = namaKategoriCtrl.text.trim(); // Ambil teks nama

    if (nama.isEmpty) {
      // Tampilkan pesan jika nama kosong
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Nama kategori tidak boleh kosong')),
      );
      return;
    }

    setState(() => loading = true); // Tampilkan loading

    try {
      final res = await http.post(
        Uri.parse('$baseUrl/kategori.php'), // Endpoint API kategori
        body: {
          'action': 'tambah', // Parameter action tambah
          'nama_kategori': nama,
          'jenis': jenis,
          'user_id': widget.userId,
        },
      );

      final data = json.decode(res.body); // Decode respons JSON

      // Tampilkan pesan dari server
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(data['pesan'] ?? 'Gagal')),
      );

      // Jika berhasil, kembali ke halaman Beranda
      if (data['success'] == true || data['success'] == 'true') {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => BerandaScreen(), // NOTE: jika butuh userId, perlu ditambahkan
          ),
        );
      }
    } catch (e) {
      // Tangani error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      setState(() => loading = false); // Sembunyikan loading
    }
  }

  // Fungsi navigasi bottom menu
  void _onItemTapped(int index) {
    if (index == _selectedIndex) return;
    setState(() => _selectedIndex = index);

    switch (index) {
      case 0:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => BerandaScreen()),
        );
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => DaftarTransaksiScreen(userId: widget.userId),
          ),
        );
        break;
      case 2:
      // Saat ini sudah di halaman kategori
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => TentangScreen(userId: widget.userId),
          ),
        );
        break;
      case 4:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ProfilScreen(userId: widget.userId),
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF0F4FF), // Warna latar belakang
      appBar: AppBar(
        backgroundColor: Color(0xFFB3E5FC), // Warna AppBar
        title: Text('Tambah Kategori', style: TextStyle(color: Colors.black)),
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Dropdown untuk memilih jenis kategori
            DropdownButtonFormField<String>(
              value: jenis,
              decoration: InputDecoration(
                labelText: 'Jenis',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(),
              ),
              items: ['pemasukan', 'pengeluaran']
                  .map((j) => DropdownMenuItem(value: j, child: Text(j)))
                  .toList(),
              onChanged: (val) => setState(() => jenis = val!), // Update jenis saat berubah
            ),
            SizedBox(height: 16),
            // Input nama kategori
            TextField(
              controller: namaKategoriCtrl,
              decoration: InputDecoration(
                labelText: 'Nama Kategori',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 24),
            // Tombol simpan
            loading
                ? CircularProgressIndicator() // Jika loading, tampilkan loading
                : ElevatedButton.icon(
              onPressed: simpanKategori,
              icon: Icon(Icons.save),
              label: Text('Simpan'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                minimumSize: Size(double.infinity, 48),
              ),
            ),
          ],
        ),
      ),
      // BottomNavigationBar untuk navigasi antar halaman
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: "Transaksi"),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: "Kategori"),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: "Tentang"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }
}
