// Import package Flutter dan SharedPreferences
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Import halaman lain yang diperlukan
import 'login_screen.dart';
import 'beranda_screen.dart';
import 'daftar_transaksi_screen.dart';
import 'tambah_kategori_screen.dart';
import 'tentang_screen.dart';

// Membuat class ProfilScreen sebagai StatefulWidget
class ProfilScreen extends StatefulWidget {
  final String userId; // Menerima userId dari halaman sebelumnya
  const ProfilScreen({Key? key, required this.userId}) : super(key: key);

  @override
  _ProfilScreenState createState() => _ProfilScreenState();
}

class _ProfilScreenState extends State<ProfilScreen> {
  String name = ''; // Variabel untuk menyimpan nama pengguna
  String email = ''; // Variabel untuk menyimpan email pengguna
  int _selectedIndex = 4; // Indeks default BottomNavigationBar adalah Profil (4)

  @override
  void initState() {
    super.initState();
    loadUserData(); // Memuat data pengguna saat pertama kali dibuka
  }

  // Fungsi untuk mengambil nama dan email dari SharedPreferences
  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      name = prefs.getString('name') ?? 'Nama tidak ditemukan';
      email = prefs.getString('email') ?? 'Email tidak ditemukan';
    });
  }

  // Fungsi untuk menangani navigasi saat menu BottomNavigationBar ditekan
  void _onItemTapped(int index) {
    if (index == _selectedIndex) return; // Tidak melakukan apa-apa jika menu yang sama ditekan

    switch (index) {
      case 0:
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => BerandaScreen()));
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => DaftarTransaksiScreen(userId: widget.userId)),
        );
        break;
      case 2:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => TambahKategoriScreen(userId: widget.userId, jenis: 'pemasukan')),
        );
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => TentangScreen(userId: widget.userId)),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFE1F5FE), // Warna latar belakang biru pastel
      appBar: AppBar(
        backgroundColor: Color(0xFFB3E5FC), // Warna AppBar biru muda
        title: Text('Profil Akun Saya', style: TextStyle(color: Colors.black)),
        iconTheme: IconThemeData(color: Colors.black), // Icon hitam
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0), // Padding isi body
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Avatar pengguna di tengah
            Center(
              child: CircleAvatar(
                radius: 40,
                backgroundColor: Colors.purple,
                child: Text(
                  name.isNotEmpty ? name[0].toUpperCase() : '?', // Inisial nama
                  style: TextStyle(fontSize: 40, color: Colors.white),
                ),
              ),
            ),
            SizedBox(height: 20),
            // Menampilkan label dan nama
            Text('Nama Lengkap:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(name, style: TextStyle(fontSize: 16)),
            SizedBox(height: 12),
            // Menampilkan label dan email
            Text('Email:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(email, style: TextStyle(fontSize: 16)),
            Spacer(), // Spacer agar tombol logout di bawah
            Center(
              child: ElevatedButton.icon(
                onPressed: () async {
                  // Menghapus semua data login saat logout
                  SharedPreferences prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  // Kembali ke halaman login dan menghapus semua riwayat halaman sebelumnya
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => LoginScreen()),
                        (route) => false,
                  );
                },
                icon: Icon(Icons.logout),
                label: Text('Logout'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red), // Tombol merah
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex, // Indeks aktif
        onTap: _onItemTapped, // Fungsi navigasi
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: "Transaksi"),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: "Kategori"),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: "Tentang"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }
}
