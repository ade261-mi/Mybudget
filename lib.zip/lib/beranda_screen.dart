// Import pustaka Flutter dan package eksternal yang dibutuhkan
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; // Untuk menyimpan data login
import 'package:pie_chart/pie_chart.dart'; // Untuk menampilkan grafik pie
import 'package:http/http.dart' as http; // Untuk request ke API
import 'dart:convert'; // Untuk konversi JSON

// Import file internal aplikasi
import 'login_screen.dart';
import 'config.dart';
import 'daftar_transaksi_screen.dart';
import 'tambah_kategori_screen.dart';
import 'tentang_screen.dart';
import 'profil_screen.dart';

// Deklarasi class utama yang merupakan StatefulWidget
class BerandaScreen extends StatefulWidget {
  @override
  State<BerandaScreen> createState() => _BerandaScreenState();
}

// State dari BerandaScreen
class _BerandaScreenState extends State<BerandaScreen> {
  String name = ''; // Menyimpan nama user
  String userId = ''; // Menyimpan ID user
  double pemasukan = 0; // Total pemasukan
  double pengeluaran = 0; // Total pengeluaran
  int _selectedIndex = 0; // Indeks tab navigasi aktif

  @override
  void initState() {
    super.initState();
    loadUserData(); // Memuat data user saat pertama kali halaman dibuka
  }

  // Fungsi untuk memuat nama dan userId dari SharedPreferences
  Future<void> loadUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      name = prefs.getString('name') ?? '';
      userId = prefs.getString('user_id') ?? '';
    });
    await fetchSummary(); // Setelah dapat userId, ambil data ringkasan keuangan
  }

  // Fungsi untuk mengambil data ringkasan pemasukan dan pengeluaran dari API
  Future<void> fetchSummary() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/summary.php?user_id=$userId'));
      final data = json.decode(response.body);

      if (data['success']) {
        setState(() {
          pemasukan = double.tryParse(data['summary']['pemasukan'].toString()) ?? 0;
          pengeluaran = double.tryParse(data['summary']['pengeluaran'].toString()) ?? 0;
        });
      }
    } catch (e) {
      print("Error summary: $e"); // Jika gagal, tampilkan di konsol
    }
  }

  // Fungsi logout: hapus data user dari SharedPreferences dan kembali ke halaman login
  void logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear(); // Hapus semua data tersimpan
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginScreen()));
  }

  // Fungsi navigasi bottom navigation bar
  void _onItemTapped(int index) {
    if (index == _selectedIndex) return; // Jika indeks sama, tidak lakukan apa-apa
    setState(() => _selectedIndex = index); // Perbarui indeks

    // Pindah halaman berdasarkan indeks
    switch (index) {
      case 0:
        break; // Sudah di halaman beranda
      case 1:
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => DaftarTransaksiScreen(userId: userId),
        ));
        break;
      case 2:
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => TambahKategoriScreen(userId: userId, jenis: 'pemasukan'),
        ));
        break;
      case 3:
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => TentangScreen(userId: userId),
        ));
        break;
      case 4:
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => ProfilScreen(userId: userId),
        ));
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final saldo = pemasukan - pengeluaran; // Hitung saldo total
    final Map<String, double> dataMap = {
      "Pemasukan": pemasukan,
      "Pengeluaran": pengeluaran,
    };

    return Scaffold(
      backgroundColor: Color(0xFFF1F8FF), // Warna latar belakang
      appBar: AppBar(
        backgroundColor: Color(0xFFB3E5FC), // Warna appbar
        foregroundColor: Colors.black,
        title: Text('MyBudget - $name'), // Judul dengan nama user
        actions: [
          IconButton(icon: Icon(Icons.logout), onPressed: logout), // Tombol logout
        ],
      ),
      body: RefreshIndicator(
        onRefresh: fetchSummary, // Tarik untuk menyegarkan data
        child: ListView(
          padding: EdgeInsets.all(16), // Jarak padding luar
          children: [
            Text(
              'Halo, $name 👋', // Sapaan user
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text('Ringkasan keuangan kamu hari ini:', style: TextStyle(fontSize: 16)),
            SizedBox(height: 20),
            Card(
              elevation: 4,
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16), // Padding dalam kartu
                child: Column(
                  children: [
                    PieChart(
                      dataMap: dataMap, // Data pemasukan dan pengeluaran
                      animationDuration: Duration(milliseconds: 800), // Durasi animasi
                      chartLegendSpacing: 32,
                      chartRadius: MediaQuery.of(context).size.width / 2.2,
                      colorList: [Colors.green, Colors.redAccent], // Warna pie chart
                      chartType: ChartType.ring, // Tipe diagram lingkaran
                      ringStrokeWidth: 30,
                      legendOptions: LegendOptions(
                        showLegends: true,
                        legendPosition: LegendPosition.bottom,
                      ),
                      chartValuesOptions: ChartValuesOptions(
                        showChartValuesOutside: true,
                        decimalPlaces: 0,
                        showChartValues: true,
                      ),
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Saldo: Rp ${saldo.toStringAsFixed(0)}', // Tampilkan saldo akhir
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: saldo >= 0 ? Colors.green : Colors.red, // Warna tergantung saldo
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex, // Indeks navigasi aktif
        onTap: _onItemTapped, // Fungsi saat ikon diklik
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color(0xFFE1F5FE),
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: "Transaksi"),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: "Kategori"),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: "Tentang"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }
}
