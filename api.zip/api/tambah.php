<?php
include 'koneksi.php';

// Ambil data dari form (x-www-form-urlencoded atau form biasa)
$user_id  = $_POST['user_id'] ?? null;
$jenis    = $_POST['jenis'] ?? null;
$jumlah   = $_POST['jumlah'] ?? null;
$kategori = $_POST['kategori'] ?? null;
$catatan  = $_POST['catatan'] ?? null;

// Validasi data wajib
if (!$user_id || !$jenis || !$jumlah || !$kategori) {
    echo json_encode(["success" => false, "pesan" => "Data tidak lengkap."]);
    exit;
}

// Query insert
$query = $conn->query("INSERT INTO transactions (user_id, jenis, jumlah, kategori, catatan)
VALUES ('$user_id', '$jenis', '$jumlah', '$kategori', '$catatan')");

if ($query) {
    echo json_encode(["success" => true, "pesan" => "Transaksi berhasil ditambahkan"]);
} else {
    echo json_encode(["success" => false, "pesan" => "Gagal menambahkan transaksi"]);
}
?>
