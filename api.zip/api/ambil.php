<?php
include 'koneksi.php';

// Ambil id_transaksi dari POST (x-www-form-urlencoded)
$id_transaksi = $_POST['id_transaksi'] ?? null;

if (!$id_transaksi) {
    echo json_encode([
        "success" => false,
        "pesan" => "ID transaksi tidak dikirim."
    ]);
    exit;
}

// Jalankan query untuk ambil data transaksi
$query = $conn->query("SELECT * FROM transactions WHERE id_transaksi='$id_transaksi'");
$data = $query->fetch_assoc();

if ($data) {
    echo json_encode([
        "success" => true,
        "data" => $data
    ]);
} else {
    echo json_encode([
        "success" => false,
        "pesan" => "Transaksi tidak ditemukan"
    ]);
}
?>
