<?php
include 'koneksi.php';

$id = $_POST['id_transaksi'] ?? null;

if ($id) {
    $query = $conn->query("DELETE FROM transactions WHERE id_transaksi = '$id'");

    if ($query) {
        echo json_encode(["success" => true, "pesan" => "Transaksi berhasil dihapus"]);
    } else {
        echo json_encode(["success" => false, "pesan" => "Gagal menghapus transaksi"]);
    }
} else {
    echo json_encode(["success" => false, "pesan" => "ID transaksi tidak dikirim"]);
}
?>
