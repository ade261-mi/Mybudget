<?php
$host = "localhost";
$user = "fore6986_afa";
$pass = "selviana16#";
$db   = "fore6986_db_afa";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die(json_encode(["success" => false, "pesan" => "Gagal koneksi ke database"]));
}
?>
