<?php
include 'koneksi.php';

$id_transaksi = $_POST['id_transaksi'] ?? '';
$jenis = $_POST['jenis'] ?? '';
$jumlah = $_POST['jumlah'] ?? '';
$kategori = $_POST['kategori'] ?? '';
$catatan = $_POST['catatan'] ?? '';

if ($id_transaksi && $jenis && $jumlah && $kategori) {
    $query = $conn->query("UPDATE transactions SET
        jenis='$jenis',
        jumlah='$jumlah',
        kategori='$kategori',
        catatan='$catatan'
        WHERE id_transaksi='$id_transaksi'
    ");

    if ($query) {
        echo json_encode(["success" => true, "pesan" => "Transaksi berhasil diubah"]);
    } else {
        echo json_encode(["success" => false, "pesan" => "Gagal mengubah transaksi"]);
    }
} else {
    echo json_encode(["success" => false, "pesan" => "Data tidak lengkap"]);
}
?>
