<?php
include 'koneksi.php';

$action = $_POST['action'] ?? ''; // Misal: get atau tambah

if ($action == 'get') {
    $jenis = $_POST['jenis'] ?? '';

    if (!$jenis) {
        echo json_encode([
            "success" => false,
            "pesan" => "Jenis tidak boleh kosong"
        ]);
        exit;
    }

    $query = $conn->query("SELECT * FROM kategori WHERE jenis = '$jenis'");
    $data = [];

    while ($row = $query->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode([
        "success" => true,
        "data" => $data
    ]);

} else if ($action == 'tambah') {
    $nama_kategori = $_POST['nama_kategori'] ?? '';
    $jenis = $_POST['jenis'] ?? '';

    if (!$nama_kategori || !$jenis) {
        echo json_encode(["success" => false, "pesan" => "Data tidak lengkap"]);
        exit;
    }

    $query = $conn->query("INSERT INTO kategori (nama_kategori, jenis) VALUES ('$nama_kategori', '$jenis')");

    if ($query) {
        echo json_encode(["success" => true, "pesan" => "Kategori berhasil ditambahkan"]);
    } else {
        echo json_encode(["success" => false, "pesan" => "Gagal menambahkan kategori"]);
    }
} else {
    echo json_encode(["success" => false, "pesan" => "Aksi tidak dikenali"]);
}
?>
