<?php
include 'koneksi.php';

$name     = $_POST['name'] ?? '';
$email    = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (!$name || !$email || !$password) {
    echo json_encode(["success" => false, "pesan" => "Semua field wajib diisi"]);
    exit;
}

$cek = $conn->query("SELECT * FROM users WHERE email='$email'");
if ($cek->num_rows > 0) {
    echo json_encode(["success" => false, "pesan" => "Email sudah terdaftar"]);
    exit;
}

$conn->query("INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')");

echo json_encode(["success" => true, "pesan" => "Registrasi berhasil"]);
?>
